#!/bin/bash

atualiza=0
debug=0
silently=0
tp_dev="dev"
tp_srv="srv"
logfile=
logfileparam=

function apresenta_uso
{
    echo "Instala o ambiente da ferramenta de TCC para o Moodle
    \$ ./instala_tcc.sh [opções]

    Opções:
    -h, --help                      Apresenta este manual
    -d, --debug                     Debug da instalação do clef-solo (padrao: Não)
    -s, --silently                  Sem apresentar mensagens (padrao: Não)
    -L, --logfile                   Define a localização do arquivo de log

    -t, --tipo [dev,srv]            Define o tipo de instacao, que pode ser:
                                        - {dev}: Ambiente de Desenvolvimento
                                        - {srv}: Ambiente de Produção (Servidor)

    -a, --atualiza                  Atualiza a instalação do chef-solo (padrao: Não)

    Examplos:
    \$ ./instala.sh -t dev -a
    \$ ./instala.sh -t srv";
}

function pega_tipo
{
    if [ $1 = "dev" ] || [ $1 = "srv" ]; then
        tipo=$1
    else
        if [ $silently -eq 0 ]; then echo "Parâmetro de tipo incorreto: ( -t $1 )"; fi
        exit 1
    fi
}

# a=/tmp/xx/file.tar.gz
# xpath=${a%/*}
# xbase=${a##*/}
# xfext=${xbase##*.}
# xpref=${xbase%.*}
# echo;echo path=${xpath};echo pref=${xpref};echo ext=${xfext}

#path=/tmp/xx
#pref=file.tar
#ext=gz

function verifica_logfile
{
    wfilename=$1
    wpath=${wfilename%/*}
    wbase=${wfilename##*/}

    if [ $debug -eq 1 ]; then echo "paramentro = $1"; fi
    if [ $debug -eq 1 ]; then echo "localização do arquivo = $wfilename"; fi
    if [ $debug -eq 1 ]; then echo "caminho = $wpath"; fi
    if [ $debug -eq 1 ]; then echo "arquivo = $wbase"; fi
    if [ -d "$wpath" ]; then
        if [ "$wbase" != '' ]; then
            logfile=$1
        else
            if [ $silently -eq 0 ]; then echo "Arquivo de log não pode ser vazio"; fi
            exit 1
        fi
    else
        if [ $silently -eq 0 ]; then echo "Diretório para log não encontrado: ( $wpath )"; fi
        exit 1
    fi
}

function instala_chef-solo
{
    if [ $debug -eq 1 ]; then echo ">>> instalando chef-solo"; fi
    curl -L https://www.opscode.com/chef/install.sh | sudo bash -s -- -v 12.5.1
    chefSoloExists=$(which chef-solo | if [ "$(tee)" = '' ]; then echo fase; else echo true;fi)
    if [ $chefSoloExists = true ]; then
        chefSoloVersion=$(chef-solo -v)
    else
        chefSoloVersion="Não instalado!"
    fi

    if [ $silently -eq 0 ] && [ $chefSoloExists = true ]; then echo "Chef-solo instalado/atualizado com sucesso: $chefSoloVersion"; fi
}

while [ "$1" != "" ]; do
    case $1 in
        -t | --tipo )           shift
                                pega_tipo $1
                                ;;
        -a | --atualiza )       atualiza=1
                                ;;
        -d | --debug )          debug=1
                                ;;
        -s | --silently )       silently=1
                                ;;
        -L | --logfile )        shift
                                verifica_logfile $1
                                ;;
        -h | --help )           apresenta_uso
                                exit
                                ;;
        * )                     apresenta_uso
                                exit 1
    esac
    shift
done

if [ $debug -eq 1 ]; then echo "Silently..: [$silently]"; fi
if [ $debug -eq 1 ]; then echo "Tipo......: [$tipo]"; fi

if [ $silently -eq 0 ] || [ $debug -eq 1 ]; then
    echo "Iniciando a instalação do ambiente da ferramenta de TCC";
fi

chefSoloVersion="Não instalado!"
chefSoloExists=$(which chef-solo | if [ "$(tee)" = '' ]; then echo false; else echo true;fi)

if [ $debug -eq 1 ]; then
    echo ">>> chefSoloExists> $chefSoloExists"
fi

if [ $chefSoloExists = true ]; then
    chefSoloVersion=$(chef-solo -v)
fi

if [ $debug -eq 1 ]; then echo ">>> chefSoloVersion=chef-solo -v > $chefSoloVersion"; fi

if [ $chefSoloExists = true ]; then
    if [ $atualiza -eq 1 ]; then
        if [ $silently -eq 0 ]; then echo "Chef-solo já instalado: $chefSoloVersion. Atualizando..."; fi
        instala_chef-solo
    else
        if [ $silently -eq 0 ]; then echo "Chef-solo já instalado: $chefSoloVersion"; fi
    fi
else
    if [ $silently -eq 0 ]; then echo "Chef-solo não encontrado. Instalando..."; fi
    instala_chef-solo
fi

if [ "$logfile" != '' ]; then
    logfileparam="-L $logfile"
fi

if [ "$tipo" = "$tp_dev" ]; then
    if [ $silently -eq 0 ]; then echo "Instalando ambiente de desenvolvimento do TCC"; fi
        sudo chef-solo -c solo.rb -j tcc_dev.json -l info $logfileparam
else
    if [ "$tipo" = "$tp_srv" ] ;then
        if [ $silently -eq 0 ]; then echo "Instalando ambiente de produção do TCC"; fi
        sudo chef-solo -c solo.rb -j tcc_srv.json -l info $logfileparam
    fi
fi
