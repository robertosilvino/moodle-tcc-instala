#!/bin/bash

# scp -r rsc@$1:workspace/chef-tcc /home/rsc/.
scp -r rsc@$1:/home/rsc/workspace/chef-tcc /home/rsc/.
# scp -r rsc@192.168.25.41:/home/rsc/workspace/chef-tcc /home/rsc/.

sudo ./instala_tcc.sh -t dev
