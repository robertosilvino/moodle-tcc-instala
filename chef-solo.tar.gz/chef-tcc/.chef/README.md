.chef
---------

This directory contains configuration files and the secret file to be used to encrypt the contents of your data bags. 

Command to generate **encrypted_data_bag_secret** file

    cd .chef
    openssl rand -base64 1024 > encrypted_data_bag_secret
    
    