#require 'mkmf'

current_dir = File.absolute_path(File.dirname(__FILE__))

chef_repo_path current_dir

#file_cache_path   find_executable 'chef-solo'
file_cache_path   "/root/chef-solo"
cookbook_path     [ current_dir + "/cookbooks" ]
role_path         [ current_dir + "/roles" ]
data_bag_path     [ current_dir + "/data_bags" ]

#chef_zero.enabled true

#chef_server_url   'http://127.0.0.1:8889'
#node_name         'tcc_server'
#client_key        "#{current_dir}/.chef/tcc_rsa.pem"

knife[:editor]      = "/usr/bin/vim"
knife[:secret_file] = "#{File.join(current_dir, '/encrypted_data_bag_secret')}"
encrypted_data_bag_secret "#{current_dir}/.chef/encrypted_data_bag_secret"