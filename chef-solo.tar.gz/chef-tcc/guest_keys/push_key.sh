#!/bin/bash

scp -r id_rsa* $1:.ssh
