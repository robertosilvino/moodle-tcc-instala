#!/bin/bash

chefSoloVersion=$(chef-solo -v)
chefSoloExists=$(if [ -n "$chefSoloVersion" ]; then echo true; else echo false; fi)

#if []; then
    sudo curl -L https://www.opscode.com/chef/install.sh | sudo bash
    chef-solo -v
#fi

chef-solo -c solo.rb -j tcc_dev.json -l info

function print_help {
        echo ""
        echo "Instalação do ambiente de desenvolvimento para o TCC"
        echo "Sintaxe: ./install.sh [dev,srv] <database_name>"
}

function restore_dump {
# Para arquivos .tar.gz:
# tar xfzO <backup_name>.tar.gz | mysql -u root <database_name>
# Para arquivos .gz:
# zcat <backup_name>.gz | mysql -u root <database_name>
        zcat $file | mysql -u root $database
}

tipo=$1
param2=$2
if [ -z $tipo ]; then
        print_help
elif [ -z $param2 ]; then
        print_help
elif [ ! -e $file ]; then
        echo "Arquivo inválido"
        exit -1
else
        restore_dump
fi
