name 'deploy'
description 'Configurações e usuários para publicação de código'
run_list(
    'recipe[user::data_bag]',
    'recipe[git_user::data_bag]'
)
default_attributes(
    'users' => [
        'deploy'
    ]
)
