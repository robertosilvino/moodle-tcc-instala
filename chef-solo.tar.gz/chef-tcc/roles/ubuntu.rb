name 'ubuntu'
description 'Ubuntu Server essential applications and configurations'
default_attributes(
    'locale' => {
        :lang => 'pt_BR.utf8',
        :language_packs => ['pt']
    }
)
run_list(
    'recipe[ubuntu]',
    'recipe[ubuntu::brasil]',
    'recipe[locale]',
    'recipe[apt]',
#    'recipe[git::ppa]',
    'recipe[git]',
    'recipe[build-essential]',
    'recipe[dpkg_packages]',
    'recipe[htop]',
    'recipe[vim]'
)