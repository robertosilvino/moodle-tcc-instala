name 'passenger'
description 'Install and configure Nginx + Passenger'
run_list(
  'recipe[passenger_nginx]',
  'recipe[nodejs::nodejs_from_package]'
)
override_attributes(
    'passenger_nginx' => {
        'ruby' => '/usr/local/bin/ruby'
    }
)