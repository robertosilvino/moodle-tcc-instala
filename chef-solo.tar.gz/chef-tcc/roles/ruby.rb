name 'ruby'
description 'Install updated ruby'
run_list(
    'recipe[ruby]',
    'recipe[imagemagick]',
    'recipe[imagemagick::rmagick]'
)
