name 'test_smf'
maintainer 'test'
maintainer_email 'test@example.com'
license 'MIT'
description 'test cookbook for smf'
long_description 'test cookbook for smf'
version '0.1.0'

depends 'smf'
