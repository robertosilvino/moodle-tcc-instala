This is a test cookbook for yum for use by chefspec
