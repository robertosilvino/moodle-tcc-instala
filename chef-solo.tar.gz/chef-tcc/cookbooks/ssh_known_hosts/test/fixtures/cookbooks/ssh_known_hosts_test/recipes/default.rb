ssh_known_hosts_entry 'github.com'
