name 'ssh_known_hosts_test'
version '0.0.1'

depends 'ssh_known_hosts'
