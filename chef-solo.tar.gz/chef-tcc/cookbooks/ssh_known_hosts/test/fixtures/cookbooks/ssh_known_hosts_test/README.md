ssh_known_hosts_test
====================

An cookbook for testing ssh_known_hosts
