name              'latex'
maintainer        'Universidade Federal de Santa Catarina'
maintainer_email  'roberto.silvino@ufsc.br'
license           'Apache 2.0'
description       'Installs/Configures LaTeX'
long_description  IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version           '0.1.0'

supports          'ubuntu', '>= 12.04'

depends           'ark'

#recipe            'latex::default', 'Install LaTeX'
#recipe            'latex::install', 'Install LaTeX'
#recipe            'latex::remove', 'Remove LaTeX'
