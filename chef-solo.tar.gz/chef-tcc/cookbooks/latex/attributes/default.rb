#<> MyApp Admin Group: The group allowed to manage MyApp.
default['latex']['cookbook_template'] = 'latex'
default['latex']['install_dir']       = '/usr/local/install_latex_chef'
default['latex']['tex_dir']           = '/usr/local/texlive'
default['latex']['version']           =  '2014'
default['latex']['repository']        =  'http://linorg.usp.br/CTAN/'
