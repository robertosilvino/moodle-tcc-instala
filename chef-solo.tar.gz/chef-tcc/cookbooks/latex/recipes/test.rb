#
# Cookbook Name:: LaTeX
# Recipe:: test
#
# Copyright (C) 2015 Universidade Federal de Santa Catarina
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

require_relative '../libraries/common'

latex_common    = Latex::Common.new(node['latex']['tex_dir'], node['latex']['version'])
node.run_state['texlive_dir']     = latex_common.texlive_path
node.run_state['new_env_content'] = latex_common.mount_environment_path
node.run_state['env_file_name']   = latex_common.env_file_name
node.run_state['latex_exists']    = latex_common.latex_exists?
node.run_state['abntex2_exists']  = latex_common.abntex2_exists?

log ">>>>>10 exec TEST > node.run_state['abntex2_exists']?" do
  message lazy { ">>>>>10 exec message TEST > node.run_state['abntex2_exists']? : #{ node.run_state['abntex2_exists']  }"}
  level :info
end

include_recipe 'latex::install'

ruby_block 'set run_state abntex2_exists after install' do
  block do
    node.run_state['abntex2_exists'] = latex_common.abntex2_exists?
  end
end

log ">>>>>20 exec TEST > node.run_state['abntex2_exists']?" do
  message lazy { ">>>>>20 exec message TEST > node.run_state['abntex2_exists']? : #{ node.run_state['abntex2_exists']  }"}
  level :info
  only_if { node.run_state['abntex2_exists']}
end

include_recipe 'latex::remove'

ruby_block 'set run_state abntex2_exists after remove' do
  block do
    node.run_state['abntex2_exists'] = latex_common.abntex2_exists?
  end
end

log ">>>>>30 exec TEST > node.run_state['abntex2_exists']?" do
  message lazy { ">>>>>30 exec message TEST > node.run_state['abntex2_exists']? : #{ node.run_state['abntex2_exists']  }"}
  level :info
  not_if { node.run_state['abntex2_exists']}
end
