#
# Cookbook Name:: LaTeX
# Recipe:: install
#
# Copyright (C) 2015 Universidade Federal de Santa Catarina
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

require_relative '../libraries/common'

latex_common    = Latex::Common.new(node['latex']['tex_dir'], node['latex']['version'])
node.run_state['texlive_dir']     = latex_common.texlive_path
env_file_name   = latex_common.env_file_name

resource_name = "Latex_#{node['latex']['version']}"
ruby_block 'set run_state install_start' do
  block do
    node.run_state["install_start_#{ resource_name }"] = Time.now
    Chef::Log.debug(">>>>>> set install_start_#{ resource_name } = #{Time.now}")
  end
end

log ">>>>>> Creating #{ resource_name }" do
  message ">>>>>> Creating #{ resource_name }"
  level :info
end

ruby_block 'set run_state latex_exists' do
  block do
    node.run_state['latex_exists'] = latex_common.latex_exists?
  end
end

ruby_block 'set run_state abntex2_exists' do
  block do
    node.run_state['abntex2_exists'] = latex_common.abntex2_exists?
  end
end

ruby_block 'set run_state new_env_content' do
  block do
    node.run_state['new_env_content'] = latex_common.mount_environment_path
  end
end

begin
  install_instance = node['latex']['install_dir'].split('/')[-1]
rescue
  install_instance = 'install_latex_chef'
end

begin
  repository = ( node['latex']['repository'].empty? ? '' : "-repository #{node['latex']['repository']}" )
rescue
  repository = ''
end

# delete downloaded file from previous version of texlive install
directory node['latex']['install_dir'] do
  recursive true
  action :delete
end

# download, compare, create (directories) and unpack texlive install
ark install_instance do
  append_env_path false
  url 'http://mirror.ctan.org/systems/texlive/tlnet/install-tl-unx.tar.gz'
  # checksum  '10ecfe6c72da7beda20b827823b7f287604e6d829f90cee39fd39f6a22361978'
  action :put
end

# generates texlive.profile used to automatic install
template "#{node['latex']['install_dir']}/texlive.profile" do
  cookbook node['latex']['cookbook_template']
  source 'texlive_profile_custom.erb'
  #source "texlive_profile_#{node['latex']['version']}.erb"
  #source "texlive_profile_#{node['latex']['version']}_custom.erb"
  #source "texlive_profile_#{node['latex']['version']}_minimal.erb"
  mode '0644'
  owner 'root'
  group 'root'
  variables({
    :texdir => node['latex']['tex_dir'],
    :version => node['latex']['version']
  })
end

# install LaTeX
execute 'latex_install_profile' do
  cwd node['latex']['install_dir']
  command "./install-tl -profile texlive.profile #{repository}"
  notifies :run, 'ruby_block[set run_state latex_exists]', :immediately
  notifies :run, 'ruby_block[set run_state new_env_content]', :immediately
  not_if { node.run_state['latex_exists'] }
end

# include the latex directory in the environment PATH
file env_file_name do
  owner 'root'
  group 'root'
  mode '644'
  content lazy { node.run_state['new_env_content'] }
  action :create
  not_if { node.run_state['new_env_content'].empty? }
end

# Abntex2 installation (Ubuntu and Mac OS X)
# Installation is done by LaTeX package manager itself (tlmgr):

# sudo tlmgr update --self
execute 'abntex2_update' do
  cwd node['latex']['install_dir']
  environment  "PATH" => "#{ node.run_state['texlive_dir'] }:#{ENV["PATH"]}"
  command "tlmgr update --self"
  notifies :run, 'ruby_block[set run_state abntex2_exists]', :immediately
  not_if { node.run_state['abntex2_exists'] }
end

# sudo tlmgr install abntex2 selnolig
execute 'abntex2_install' do
  cwd node['latex']['install_dir']
  environment "PATH" => "#{ node.run_state['texlive_dir'] }:#{ENV["PATH"]}"
  command "tlmgr install abntex2 selnolig"
  notifies :run, 'ruby_block[set run_state abntex2_exists]', :immediately
  not_if { node.run_state['abntex2_exists'] }
end

# sudo texhash
execute 'abntex2_hash' do
  cwd node['latex']['install_dir']
  environment "PATH" => "#{ node.run_state['texlive_dir'] }:#{ENV["PATH"]}"
  command "texhash"
  notifies :run, 'ruby_block[set run_state abntex2_exists]', :immediately
  not_if { node.run_state['abntex2_exists'] }
end

# texmf.cnf
ruby_block 'configure_texmf' do
  block do
    rc = Chef::Util::FileEdit.new("#{node['latex']['tex_dir']}/#{node['latex']['version']}/texmf-dist/web2c/texmf.cnf")
    rc.search_file_replace_line(/^openout_any\s?=\s?./, 'openout_any = a')
    rc.write_file
  end
  action :run
end

log ">>>>>> Created #{ resource_name }" do
  message lazy {">>>>>> #{ resource_name } created. Build time was " \
                "#{(Time.now - node.run_state["install_start_#{ resource_name }"]) / 60.0} minutes"}
  level :info
end
