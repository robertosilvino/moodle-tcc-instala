#
# Cookbook Name:: LaTeX
# Recipe:: remove
#
# Copyright (C) 2015 Universidade Federal de Santa Catarina
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

require_relative '../libraries/common'

latex_common = Latex::Common.new(node['latex']['tex_dir'], node['latex']['version'])
env_file_name   = latex_common.env_file_name

# remove the directory where the latex is installed
directory node['latex']['tex_dir'] do
  recursive true
  action :delete
  not_if { node['latex']['tex_dir'].empty? }
end

# remove the latex directory from the environment path
file env_file_name do
  owner 'root'
  group 'root'
  mode '644'
  content latex_common.umount_environment_path
  action :create
  not_if { latex_common.umount_environment_path.empty? }
end


