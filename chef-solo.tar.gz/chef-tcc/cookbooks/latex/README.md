# Description

Installs/Configures LaTeX
# Requirements

## Platform:

* Ubuntu (>= 12.04)

## Cookbooks:

* ark

# Attributes

* `node['latex']['cookbook_template']` - MyApp Admin Group: The group allowed to manage MyApp. Defaults to `latex`.
* `node['latex']['install_dir']` -  Defaults to `/usr/local/install_latex_chef`.
* `node['latex']['tex_dir']` -  Defaults to `/usr/local/texlive`.
* `node['latex']['version']` -  Defaults to `2014`.

# Recipes

* latex::default
* [latex::install](#latexinstall) - The recipe is awesome.
* latex::remove
* latex::test

## latex::install

The recipe is awesome. It does thing 1, thing 2 and thing 3!

  This definition does something useful.

  @param user User to run as.

  @param group User group to run as.


### Examples

  # An example of my awesome definition

    mycookbook_awesome_definition "app resources" do
      user 'appuser'
      group 'appgroup'
    end

Maintainer:: Universidade Federal de Santa Catarina (<roberto.silvino@ufsc.br>)

License:: Apache 2.0
