module Latex
  class Common
    attr_reader :env_file_name

    def initialize(tex_dir, version, env_file_name = '/etc/environment')
      @tex_dir = tex_dir
      @version = version
      @env_file_name = env_file_name

    end

    def texlive_path
      # "#{node['latex']['tex_dir']}/#{node['latex']['version']}/bin/x86_64-linux"
      "#{tex_dir}/#{version}/bin/x86_64-linux"
    end

    def latex_exists?

      cmdStr = 'kpsewhich apalike.sty ; echo $?'
      cmd = ::Mixlib::ShellOut.new(cmdStr, :returns => [0], :env => {'PATH' => "#{texlive_path}:#{ENV["PATH"]}"})
      cmd.run_command
      ::Chef::Log.debug(">>>>>> latex_exists?: command: #{cmdStr}")
      ::Chef::Log.debug(">>>>>> latex_exists?: stdout: #{cmd.stdout}")
      ::Chef::Log.debug(">>>>>> latex_exists?: status: #{cmd.status}")
      ::Chef::Log.debug(">>>>>> latex_exists?: exitstatus: #{cmd.exitstatus}")
      ::Chef::Log.debug(">>>>>> latex_exists?: error?: #{cmd.error?}")

      begin
        # pega a última linha do stdout, com a impressão do exit status, e verifica se é 0
        result = cmd.stdout.split[-1].eql?('0')
      rescue
        ::Chef::Log.debug(">>>>>> latex_exists?: rescue/stdout?: [#{cmd.stdout}]")
        result = false
      end
      #result = ::File.exists?(tex_dir)
      ::Chef::Log.info(">>>>>> LaTeX exists? : #{ result }")
      result
    end

    def abntex2_exists?

      cmdStr = 'kpsewhich abntex2cite.sty ; echo $?'
      cmd = ::Mixlib::ShellOut.new(cmdStr, :returns => [0], :env => {'PATH' => "#{texlive_path}:#{ENV["PATH"]}"})
      cmd.run_command
      ::Chef::Log.debug(">>>>>> abntex2_exists?: command: #{cmdStr}")
      ::Chef::Log.debug(">>>>>> abntex2_exists?: stdout: #{cmd.stdout}")
      ::Chef::Log.debug(">>>>>> abntex2_exists?: status: #{cmd.status}")
      ::Chef::Log.debug(">>>>>> abntex2_exists?: exitstatus: #{cmd.exitstatus}")
      ::Chef::Log.debug(">>>>>> abntex2_exists?: error?: #{cmd.error?}")

      begin
        # pega a última linha do stdout, com a impressão do exit status, e verifica se é 0
        result = cmd.stdout.split[-1].eql?('0')
      rescue
        ::Chef::Log.debug(">>>>>> abntex2_exists?: rescue/stdout?: [#{cmd.stdout}]")
        result = false
      end
      #result = ::File.exists?(tex_dir)
      ::Chef::Log.info(">>>>>> abntex2_exists? : #{ result }")
      result
    end

    def umount_environment_path
      #env_file_name = '/etc/environment'

      env_content = ::File.read(env_file_name)
      new_env_content = ''

      # if do not find texlive_dir then includes
      if  env_content.include?(tex_dir)

        env_content.each_line { | line |
          if line.include?('PATH=')
            # verificar se existe versão antiga e remover
            # dar split nos : e remontar sem a linha com tex_dir
            new_line = line
            if new_line.include?(tex_dir)   # /usr/local/texlive_chef
              a_paths = []
              new_line.delete("\n").delete('\"').split('=')[1].split(":").each { | path |
                a_paths.push(path) unless path.include?(tex_dir)

              }
              new_line = "PATH=\"#{a_paths.join(':')}\""
            end

          end
          new_env_content += "#{new_line}\n"
        }
      else
        new_env_content = env_content
      end
      new_env_content

    end

    def mount_environment_path
      texlive_dir = texlive_path
      #env_file_name = '/etc/environment'

      env_content = ::File.read(env_file_name)
      new_env_content = ''

      # if do not find texlive_dir then includes
      if  !env_content.include?(texlive_dir) ||
          env_content.include?(tex_dir)
        included = false

        env_content.each_line { | line |
          if line.include?('PATH=')
            # verificar se existe versão antiga e remover
            # dar split nos : e remontar sem a linha com tex_dir
            new_line = line
            if new_line.include?(tex_dir)   # /usr/local/texlive_chef
              a_paths = []
              new_line.delete("\n").delete('\"').split('=')[1].split(":").each { | path |
                a_paths.push(path) unless path.include?(tex_dir) &&
                    !path.include?(texlive_dir)

              }
              new_line = "PATH=\"#{a_paths.join(':')}\""
            end

            # se ainda não incluiu e se não encontrar
            if !included && !new_line.include?(texlive_dir)
              # está apenas incluindo
              new_line = "PATH=\"#{texlive_dir}:#{new_line.delete("\n").delete('\"').split('=')[1]}\""
              included = true
            end
          end
          new_env_content += "#{new_line}\n"
        }
      else
        new_env_content = env_content
      end

      new_env_content
    end

    private

    attr_reader :tex_dir, :version


  end
end
