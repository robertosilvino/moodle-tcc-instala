require 'chef/resource/lwrp_base'

class Chef
  class Resource
    class TccMysqlConfig < Chef::Resource::LWRPBase
      self.resource_name = :tcc_mysql_config
      # self.resource_name = :tcc_base
      actions :config
      default_action :config

      attribute :name,                   kind_of: [ String ], name_attribute: true

      provides :tcc_mysql_config
      # provides :tcc_base
    end
  end
end