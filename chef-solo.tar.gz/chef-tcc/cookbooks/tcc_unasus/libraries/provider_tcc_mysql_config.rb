require 'active_support/all'

class Chef
  class Provider
    class TccMysqlConfig < Chef::Provider::LWRPBase
      include Chef::DSL::IncludeRecipe
      include Chef::Mixin::ShellOut

      provides :tcc_mysql_config, os: 'linux' if respond_to?(:provides)

      action :config do
        initialize_run_state
        converge_by("Config Mysql") do
          ruby_block 'set run_state install_start' do
            block do
              node.run_state["install_start_#{ new_resource.name }"] = Time.now
              Chef::Log.info(">>>>>> Config Mysql - set install_start_#{ new_resource.name} = #{Time.now}")
            end
          end

          #install_start = Time.now
          log ">>>>>> Configing Mysql #{ @new_resource.name }" do
            message ">>>>>> Configing Mysql #{ new_resource.name }"
            level :info
          end

          config_mysql(@new_resource)

          log ">>>>>> Mysql Configured #{@new_resource.name}" do
            message lazy {">>>>>> #{ new_resource.name } created. Build time was " \
                "#{(Time.now - node.run_state["install_start_#{ new_resource.name }"]) / 60.0} minutes"}
            level :info
          end
        end
      end

      def config_mysql(resource)

        resource_name = "MySQL@#{node['mysql']['service_name']}"
        ruby_block 'set run_state install_start' do
          block do
            node.run_state["install_start_#{ resource_name }"] = Time.now
            Chef::Log.debug(">>>>>> set install_start_#{ resource_name } = #{Time.now}")
          end
        end

        log ">>>>>> Creating #{ resource_name }" do
          message ">>>>>> Creating #{ resource_name }"
          level :info
        end

        mysql2_chef_gem 'default' do
          action :install
        end

        databasename_test = 'dbTestChefInstall'

        mysql_service node['mysql']['service_name'] do
          # if node['mysql']['data_dir'] is empty, a database will be initialized, and a root user will be set up with
          # initial_root_password. If this directory already contains database files, no action will be taken.

          # if node['mysql']['data_dir'].empty? then mysql_service.data_dir will be omitted, so
          # it will use the default data dir to the platform's native location.
          data_dir node['mysql']['data_dir'] unless node['mysql']['data_dir'].empty?
          port node['mysql']['port']
          version node['mysql']['version']  #'5.5'
          bind_address node['mysql']['bind_address']
          initial_root_password lazy { node.run_state['mysql_root_pass'] }
          socket lazy { node.run_state['mysql_socket'] }
          action [:create, :start]
        end

        mysql_config node['mysql']['service_name'] do
          instance node['mysql']['service_name']
          #cookbook 'unasus'
          source 'mysql_default.cnf.erb'
          config_name node['mysql']['config_name']
          #variables(:foo => node['mysql']['bind_address'])
          notifies :restart, "mysql_service[#{ node['mysql']['service_name']}]"
          action :create
        end

# seta parametro de conexão com o banco de dados
        db_connection =
            { :host => node['mysql']['bind_address'],
              :user => 'root',
              :socket   => node.run_state['mysql_socket']
            }

# inclui o parametro de senha, se houver senha de root
        if rootPassEmpty?(node['mysql']['bind_address'])
          log ">>>>>> root without password" do
            message ">>>>>> root without password"
            level :info
            notifies :run, 'ruby_block[reset run_state mysql_root_pass]', :immediately
          end
        else
          db_connection.merge(:password => node.run_state['mysql_root_pass'])
          log ">>>>>> root without password" do
            message ">>>>>> root without password"
            level :info
            notifies :run, 'ruby_block[set run_state mysql_root_pass]', :immediately
          end
        end

        mysql_database "create database: #{databasename_test} without password" do
          database_name databasename_test
          connection(db_connection)
          action :create
          only_if "/usr/bin/mysql -u root -h 127.0.0.1 -P 3306 -e 'show databases'"
          notifies :run, 'ruby_block[reset run_state mysql_root_pass]', :immediately
        end

        mysql_database "create database: #{databasename_test} with password" do
          database_name databasename_test
          connection(db_connection)
          action :create
          not_if "/usr/bin/mysql -u root -h 127.0.0.1 -P 3306 -e 'show databases'"
          notifies :run, 'ruby_block[set run_state mysql_root_pass]', :immediately
        end

        bash 'table creation test. Database: dbTestChef'   do
          code <<-EOF
  echo 'CREATE TABLE #{databasename_test}.table1 (name VARCHAR(20), rank VARCHAR(20));' | /usr/bin/mysql -u root -h 127.0.0.1 -P 3306 #{node.run_state['mysql_root_pass_param']};
  echo "INSERT INTO #{databasename_test}.table1 (name,rank) VALUES('captain','awesome');" | /usr/bin/mysql -u root -h 127.0.0.1 -P 3306 #{node.run_state['mysql_root_pass_param']};
          EOF
          not_if "/usr/bin/mysql -u root -h 127.0.0.1 -P 3306 #{node.run_state['mysql_root_pass_param']} -e 'show databases' | grep #{databasename_test}"
          # /usr/bin/mysql -u root -h 127.0.0.1 -P 3306 -pteste123 -e 'show databases' | grep dbTestChef;echo $?
          action :run
        end

        mysql_database "drop database: #{databasename_test}" do
          database_name databasename_test
          connection(lazy {
                       { :host => node['mysql']['bind_address'],
                         :user => 'root',
                         :socked => node.run_state['mysql_socket'],
                         :password => node.run_state['mysql_root_pass']
                       }
                     })
          action :drop
        end

        log ">>>>>> Created #{ resource_name }" do
          message lazy {">>>>>> #{ resource_name } created. Build time was " \
                "#{(Time.now - node.run_state["install_start_#{ resource_name }"]) / 60.0} minutes"}
          level :info
        end

      end
    end
  end
end

# sudo service mysql-default stop
# sudo service mysql-tcc stop
# sudo service mysql-unasus stop
# sudo service mysql-unasus2 stop
# sudo service mysqld stop
# sudo service mysql stop
# sudo apt-get --purge remove mysql* -y
# sudo rm -rf /etc/mysql-default/
# sudo rm -rf /etc/mysql-tcc/
# sudo rm -rf /etc/mysql-unasus/
# sudo rm -rf /etc/mysql-unasus2/
# sudo rm -rf /etc/mysql/
# sudo rm /etc/init/mysql-default.conf
# sudo rm /etc/init/mysql-tcc.conf
# sudo rm /etc/init/mysql-unasus.conf
# sudo rm /etc/init/mysql-unasus2.conf
# sudo rm /etc/init/mysql.conf
# sudo rm -rf /var/run/mysqld/
# sudo rm -rf /var/run/mysql-default/
# sudo rm -rf /var/run/mysql-tcc/
# sudo rm -rf /var/lib/mysql/
# sudo rm -rf /var/lib/mysql-default/
# sudo rm -rf /var/lib/mysql-tcc/

# sudo chef-client -l info -L log.txt
# tail -f log.txt
