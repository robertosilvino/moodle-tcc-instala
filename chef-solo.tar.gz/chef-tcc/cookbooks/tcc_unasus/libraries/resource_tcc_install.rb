require 'chef/resource/lwrp_base'

class Chef
  class Resource
    class TccInstall < Chef::Resource::LWRPBase
      self.resource_name = :tcc_install
      actions :install, :remove
      default_action :install

      provides :tcc_install

      attribute :name,                   kind_of: [ String ], name_attribute: true
      attribute :user_deploy,            kind_of: [ String ], default: 'deploy'
      attribute :config_dir,             kind_of: [ String ], default: 'localhost'#, name_property: true
      attribute :description,            kind_of: [ String ],  default: 'UnASUS-TCC App'
      attribute :create_db_and_user,     kind_of: [ TrueClass, FalseClass ], default: true
      attribute :database_download_site, kind_of:  [ String ], default: ''

      attribute :mysql_socket,           kind_of: [ String ], default: ''
      attribute :dbgrant_hosts,          kind_of: [ Array ], default: %w(localhost 127.0.0.1)

      attribute :dbadapter,     kind_of: [ String ], default: 'mysql2'
      attribute :dbhost,        kind_of: [ String ], default: 'localhost'
      attribute :dbname,        kind_of: [ String ], default: 'tcc_unasus'
      attribute :dbpass,        kind_of: [ String ], default: 'tcc_unasus'
      attribute :dbrootpass,    kind_of: [ String ], default: ''
      attribute :dbsocket,      kind_of: [ TrueClass, FalseClass ], default: false
      attribute :dbuser,        kind_of: [ String ], default: 'tcc'
      attribute :server_name,   kind_of: [ String ], default: '' #'localhost'
      attribute :web_root_dir,  kind_of: [ String ], default: ''

      attribute :git_auto_update, kind_of: [ TrueClass, FalseClass ], default: false
      attribute :git_repo,        kind_of: [ String ], default: 'git@gitlab.setic.ufsc.br:tcc-unasus/sistema-tcc.git'
      attribute :git_revision,    kind_of: [ String ], default: 'master'

      attribute :root_https, kind_of: [ TrueClass, FalseClass ], default: false

      attribute :delivery_method,     kind_of: [ String ], default: 'smtp'
      attribute :smtp_address,        kind_of: [ String, nil ], default: 'smtp.sistemas.ufsc.br'
      attribute :smtp_port,           kind_of: [ String, nil ], default: '25'
      attribute :smtp_authentication, kind_of: [ String, nil ], default: 'login'
      attribute :smtp_user_name,      kind_of: [ String, nil ], default: 'unasus'
      attribute :smtp_password,       kind_of: [ String, nil ], default: ''

      attribute :errbit_api_key,  kind_of: [ String, nil ], default: ''
      attribute :errbit_host,     kind_of: [ String, nil ], default: ''
      attribute :errbit_port,     kind_of: [ String, nil ], default: ''

      attribute :moodle_dbadapter,  kind_of: [ String ], default: 'mysql2default_action :install'
      attribute :moodle_dbhost,     kind_of: [ String ], default: 'localhost'
      attribute :moodle_dbname,     kind_of: [ String ], default: 'moodle_unasus2'
      attribute :moodle_dbuser,     kind_of: [ String ], default: 'moodle'
      attribute :moodle_dbpass,     kind_of: [ String ], default: ''
      attribute :moodle_dbport,     kind_of: [ String ], default: '3306'
      attribute :moodle_dbsocket,   kind_of: [ TrueClass, FalseClass ], default: false

      attribute :newrelic_license_key,  kind_of: [ String, nil ], default: ''
      attribute :newrelic_app_name,     kind_of: [ String, nil ], default: ''

      attribute :tcc_moodle_url,          kind_of: [ String ], default: ''
      attribute :tcc_moodle_token,        kind_of: [ String ], default: ''
      attribute :tcc_consumer_key,        kind_of: [ String ], default: ''
      attribute :tcc_consumer_secret,     kind_of: [ String ], default: ''
      attribute :tcc_notification_email,  kind_of: [ String, nil ], default: 'unasus@sistemas.ufsc.br'

      # def initialize(*args)
      #   super
      #   @action = :create
      #
      # end


    end
  end
end