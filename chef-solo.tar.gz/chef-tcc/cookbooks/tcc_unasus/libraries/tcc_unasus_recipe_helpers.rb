class Chef
  module TccUnasus
    module RecipeHelpers

      def mysql_path
        mysql_path = '/usr/bin/mysql'
        cmd = Mixlib::ShellOut.new('which mysql')
        cmd.run_command

        if cmd.exitstatus == 0
          mysql_path = cmd.stdout.chomp
        end
        mysql_path
      end

      def rootPassEmpty?(dbhost)
        # Verifica se consegue conectar com banco de dados sem a senha de root
        cmd_conecta = "#{mysql_path} -u root -h #{dbhost} -P 3306 -e 'show databases'"
        cmd = Mixlib::ShellOut.new(cmd_conecta)
        cmd.run_command
        cmd.exitstatus == 0
      end

      def databasename_test
        'dbTestChefInstall'
      end

      def head_root
        @new_resource.root_https ? 'https://' : 'http://'
      end

      # removes [http://] or [https://] from server_name
      def tcc_server_name
        @new_resource.server_name.sub(/^https?\:\/\//, '')
      end

      # includes [http://] or [https://] to server_name as head_root
      def wwwroot
        head_root.concat(tcc_server_name)
      end

      def git_destination
        @new_resource.config_dir
      end

      def app_dir
        temp = @new_resource.config_dir.split('/')
        temp.pop
      end

      def deploy_path
        temp = @new_resource.config_dir.split('/')
        temp.pop
        temp.join('/')
      end

      def repo_destination
        tcc_server_name.present? ? ::File.join(git_destination, 'repo') : git_destination
      end

    end
  end
end