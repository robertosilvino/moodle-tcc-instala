def initialize_run_state
  ruby_block 'set run_state mysql_root_pass_param' do
    block do
      begin
        param = node.run_state['mysql_root_pass'].blank? ? '' : "-p#{node.run_state['mysql_root_pass']}"
      rescue
        param = ''
      end
      # Chef::Log.info(">>>>>>>>> set run_state mysql_root_pass_param")
      node.run_state['mysql_root_pass_param'] = param
    end
    action :nothing
  end

  ruby_block 'reset run_state mysql_root_pass' do
    block do
      node.run_state['mysql_root_pass'] = ''
      Chef::Log.info(">>>>>>>>> reset run_state mysql_root_pass")
    end
    notifies :run, 'ruby_block[set run_state mysql_root_pass_param]', :immediately
    action :nothing
  end

  ruby_block 'set run_state mysql_root_pass' do
    block do
      root_pass = data_bag_item('db_users', 'mysql_root')['password']
      node.run_state['mysql_root_pass'] = root_pass.blank? ? nil : Shellwords.escape(root_pass)
      Chef::Log.info(">>>>>>>>> set run_state mysql_root_pass")
    end
    notifies :run, 'ruby_block[set run_state mysql_root_pass_param]', :immediately
  end

  ruby_block 'set run_state mysql_socket' do
    block do
      node.run_state['mysql_socket'] = node['mysql']['socket'].blank? ? '' : node['mysql']['socket']
      Chef::Log.info(">>>>>>>>> set run_state mysql_socket")
    end
  end
end
