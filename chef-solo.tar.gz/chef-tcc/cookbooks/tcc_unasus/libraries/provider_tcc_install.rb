require 'active_support/all'

class Chef
  class Provider
    class TccInstall < Chef::Provider::LWRPBase
      use_inline_resources

      def whyrun_supported?
        true
      end

      include Chef::DSL::IncludeRecipe
      include Chef::Mixin::ShellOut

      provides :tcc_install, os: 'linux' if respond_to?(:provides)

      action :install do
        initialize_run_state

        converge_by("Create tcc") do
          ruby_block 'set run_state install_start' do
            block do
              node.run_state["install_start_#{ new_resource.config_dir }"] = Time.now
              Chef::Log.info(">>>>>> set install_start_#{ new_resource.config_dir } = #{Time.now}")
            end
          end

          #install_start = Time.now
          log ">>>>>> Creating tcc #{ new_resource.config_dir }" do
            message ">>>>>> Creating #{ new_resource.config_dir }"
            level :info
          end

          install_tcc(@new_resource)

          log ">>>>>> Created tcc" do
            message lazy {">>>>>> #{ new_resource.config_dir } created. Build time was " \
                "#{(Time.now - node.run_state["install_start_#{ new_resource.config_dir }"]) / 60.0} minutes"}
            level :info
          end

        end

      end

      action :remove do
        converge_by("Removing tcc") do
          resource_name = @new_resource.config_dir
          remove_tcc(@new_resource)
          Chef::Log.debug "#{ resource_name } removed."
        end
      end

      private

      def install_tcc(resource)

        # Instalação no servidor
        if tcc_server_name.present?
          run_context.include_recipe 'nginx'
          user_deploy   = node['php-fpm']['user']
          group_deploy  = node['php-fpm']['group']
          sharedDir     = '/shared'

          log ">>>>>> instalação para servidor" do
            message ">>>>>> instalação para servidor"
            level :info
          end
        else
          user_deploy   = resource.user_deploy
          group_deploy  = resource.user_deploy
          sharedDir     = ''

          log ">>>>>> instalação para desenvolvimento" do
            message ">>>>>> instalação para desenvolvimento"
            level :info
          end
        end

        log ">>>>>> user_deploy [#{user_deploy}]" do
          message ">>>>>> user_deploy [#{user_deploy}]"
          level :info
        end

        package 'redis-server' do
          action :install
        end

        mysql2_chef_gem 'default' do
          action :install
        end

        # # config_dir = /home/deploy/tcc
        # git_destination = resource.config_dir
        # deploy_path = resource.config_dir.split('/')
        # app_dir = deploy_path.pop
        # deploy_path = deploy_path.join('/')
        # repo_destination = tcc_server_name.present? ? ::File.join(git_destination, 'repo') : git_destination

        bash 'cria_diretorio_deploy' do
          user user_deploy
          group group_deploy
          code "mkdir #{deploy_path}"
          only_if { !::File.exists?(deploy_path) } #&& server_name.present? }
        end

        bash 'cria_diretorio_git_destination' do
          user user_deploy
          group group_deploy
          code "mkdir -p #{git_destination}"
          only_if { !::File.exists?(git_destination) && tcc_server_name.present? }
        end

        unless resource.git_repo.empty?

          # ===========
          # repository
          # ==========

          log ">>>>>> instalação do repositório" do
            message ">>>>>> instalação do repositório"
            level :info
          end

          file "/home/#{user_deploy}/.ssh/git_wrapper.sh" do
            owner user_deploy
            group group_deploy
            mode '0755'
            content "#!/bin/sh\nexec /usr/bin/ssh -o UserKnownHostsFile=/dev/null -o \"StrictHostKeyChecking=no\" -i /home/#{user_deploy}/.ssh/git_user_rsa \"$@\"\n"
          end

          git repo_destination do
            name repo_destination
            repository resource.git_repo
            revision resource.git_revision # master(default)
            # destination repo_destination # name
            enable_checkout true
            enable_submodules true
            # user 'gest'
            # group 'gest'
            user user_deploy
            group group_deploy
            action :sync
            ssh_wrapper "/home/#{user_deploy}/.ssh/git_wrapper.sh"
            only_if { resource.git_auto_update ||
                ( !resource.git_auto_update && !::File.exists?( "#{repo_destination}" ))}
          end

        end

        # ====================
        # configuration files
        # ===================

        bash 'cria_diretorio_deploy e sub diretórios' do
          cwd deploy_path
          user user_deploy
          group group_deploy
          code "mkdir -m 2775 -p #{app_dir}#{sharedDir}/{config/,public/assets}"
        end

        file ::File.join(git_destination, "#{sharedDir}/public/assets/manifest-00.json") do
          owner user_deploy
          group group_deploy
          mode 0664
          # only if not exist file manifest-*.json
          not_if 'ls manifest-*.json'
        end

        # config: # /home/deploy/atendimento/shared/config/database.yml
        database_file = ::File.join(git_destination , "#{sharedDir}/config/database.yml")
        template database_file do
          cookbook node['tcc_unasus']['cookbook_template']
          source 'tcc_database.yml.erb'
          owner user_deploy
          group group_deploy
          mode 0644
          variables(
              :adapter   => resource.dbadapter,
              :database  => resource.dbname,
              :host      => resource.dbhost,
              :username  => resource.dbuser,
              :password  => resource.dbpass,
              :dbsocket  => resource.dbsocket,
              :socket    => resource.mysql_socket,
              :encoding  => 'utf8',
              :pool      => '20'
          )
        end

        # config: # /home/deploy/tcc/shared/config/email.yml
        config_file = ::File.join(git_destination , "#{sharedDir}/config/email.yml")
        template config_file do
          cookbook node['tcc_unasus']['cookbook_template']
          source 'tcc_email.yml.erb'
          owner user_deploy
          group group_deploy
          mode 0644
          variables(
              :delivery_method      => resource.delivery_method,
              :smtp_address         => resource.smtp_address,
              :smtp_port            => resource.smtp_port,
              :smtp_authentication  => resource.smtp_authentication,
              :smtp_user_name       => resource.smtp_user_name,
              :smtp_password        => resource.smtp_password
          )
        end


        # config: # /home/deploy/tcc/shared/config/errbit.yml
        config_file = ::File.join(git_destination , "#{sharedDir}/config/errbit.yml")
        template config_file do
          cookbook node['tcc_unasus']['cookbook_template']
          source 'tcc_errbit.yml.erb'
          owner user_deploy
          group group_deploy
          mode 0644
          variables(
              :api_key => resource.errbit_api_key,
              :host    => resource.errbit_host,
              :port    => resource.errbit_port
          )
        end

        # config: # /home/deploy/tcc/shared/config/moodle.yml
        config_file = ::File.join(git_destination , "#{sharedDir}/config/moodle.yml")
        template config_file do
          cookbook node['tcc_unasus']['cookbook_template']
          source 'tcc_moodle.yml.erb'
          owner user_deploy
          group group_deploy
          mode 0644
          variables(
              :adapter   => resource.moodle_dbadapter,
              :database  => resource.moodle_dbname,
              :host      => resource.moodle_dbhost,
              :username  => resource.moodle_dbuser,
              :password  => resource.moodle_dbpass,
              :port      => resource.moodle_dbport,
              :dbsocket  => resource.moodle_dbsocket,
              :socket    => resource.mysql_socket,
              :encoding  => 'utf8',
              :pool      => '10'
          )
        end

        # config: # /home/deploy/tcc/shared/config/newrelic.yml
        config_file = ::File.join(git_destination , "#{sharedDir}/config/newrelic.yml")
        template config_file do
          cookbook node['tcc_unasus']['cookbook_template']
          source 'tcc_newrelic.yml.erb'
          owner user_deploy
          group group_deploy
          mode 0644
          variables(
              :license_key => resource.newrelic_license_key,
              :app_name    => resource.newrelic_app_name
          )
        end

        # config: # /home/deploy/tcc/shared/config/sidekiq.yml
        config_file = ::File.join(git_destination , "#{sharedDir}/config/sidekiq.yml")
        template config_file do
          cookbook node['tcc_unasus']['cookbook_template']
          source 'tcc_sidekiq.yml.erb'
          owner user_deploy
          group group_deploy
          mode 0644
          variables(
              #:key => value,
              #:key => value
          )
        end

        # config: # /home/deploy/tcc/shared/config/tcc_config.yml
        config_file = ::File.join(git_destination , "#{sharedDir}/config/tcc_config.yml")
        template config_file do
          cookbook node['tcc_unasus']['cookbook_template']
          source 'tcc_tcc_config.yml.erb'
          owner user_deploy
          group group_deploy
          mode 0644
          variables(
              :moodle_url         => resource.tcc_moodle_url,
              :moodle_token       => resource.tcc_moodle_token,
              :consumer_key       => resource.tcc_consumer_key,
              :consumer_secret    => resource.tcc_consumer_secret,
              :notification_email => resource.tcc_notification_email
          )
        end

        #chmod 0644 $(find /home/deploy/atendimento/shared/config -type f)
        execute 'change 644' do
          command "chmod 0644 $(find #{ ::File.join(git_destination , "#{sharedDir}/config")  } -type f)"
          returns [0, 1]
        end

        # config: # /atendimento.moodle.ufsc.br.conf.erb
        site_available_conf_file = ::File.join(node['nginx']['dir'], 'sites-available', "#{resource.server_name}.conf")
        template site_available_conf_file do
          cookbook node['tcc_unasus']['cookbook_template']
          source 'tcc_ssl_nginx.conf.erb'
          #owner user_deploy
          #group group_deploy
          mode 0644
          variables(
              :server_name  => tcc_server_name,
              :web_root_dir => resource.web_root_dir,
              :pre_start    => wwwroot,
              :root_https   => resource.root_https
          )
          only_if { !::File.exists?( site_available_conf_file ) && (tcc_server_name.present?)}
        end

        # =========
        # database
        # ========

        if resource.create_db_and_user

          # # FIXME: colocar em um helper
          # # Verifica se consegue conectar com banco de dados sem a senha de root
          # cmd_conecta = "#{mysql_path} -u root -h #{resource.dbhost} -P 3306 -e 'show databases'"
          # cmd = Mixlib::ShellOut.new(cmd_conecta)
          # cmd.run_command
          # rootPassEmpty = cmd.exitstatus == 0

          # seta parametro de conexão com o banco de dados
          db_connection =
              { :host => resource.dbhost,
                :user => 'root',
                :socket   => resource.mysql_socket
              }
          # inclui o parametro de senha, se houver senha de root
          if rootPassEmpty?(resource.dbhost)
            log ">>>>>> root without password" do
              message ">>>>>> root without password"
              level :info
              notifies :run, 'ruby_block[reset run_state mysql_root_pass]', :immediately
            end
          else
            db_connection.merge(:password => resource.dbrootpass)
            log ">>>>>> root without password" do
              message ">>>>>> root without password"
              level :info
              notifies :run, 'ruby_block[set run_state mysql_root_pass]', :immediately
            end
          end

          allDatabases = Array[resource.dbname, "#{resource.dbname}_tst"]

          allDatabases.each do | dbname |
            mysql_database dbname do
              connection( db_connection )
              action :create
            end
          end

          # Query a database
          mysql_database 'flush the privileges' do
            connection db_connection
            sql        'flush privileges'
            action     :query
          end

          allDatabases.each do | dbname |
            resource.dbgrant_hosts.each do | dbgrant_host |
              mysql_database_user resource.dbuser do
                connection( db_connection )
                password resource.dbpass
                host dbgrant_host
                database_name dbname
                privileges [:all]
                action [:grant]
                # ignore_failure true
              end
            end
          end

          # Query a database
          mysql_database 'flush the privileges' do
            connection db_connection
            sql        'flush privileges'
            action     :query
          end

          # download database_download_site
          unless resource.database_download_site.empty?

            downloadfile = ::File.basename(resource.database_download_site)
            path_downloadfile = "/tmp/#{downloadfile}"

            remote_file path_downloadfile do
              source resource.database_download_site
              mode '0644'
              #checksum "3a7dac00b1" # A SHA256 (or portion thereof) of the file.
              action :create_if_missing
            end

            etc_chef = '/etc/chef'
            database_file_check = "#{etc_chef}/databse_#{resource.dbname}_restored"


            directory etc_chef do
              action :create
              not_if { ::File.exists?( etc_chef ) }
            end

            file database_file_check do
              mode '0755'
              action :nothing
            end

            log "...... restarting mysql" do
              message "...... restarting mysql"
              level :info
              only_if { ::File.exists?( path_downloadfile ) && !::File.exists?( database_file_check )}
            end

            log "...... mysql restarted" do
              message "...... mysql restarted"
              level :info
              action :nothing
            end

            mysql_service node['mysql']['service_name'] do
              data_dir node['mysql']['data_dir'] unless node['mysql']['data_dir'].empty?
              port node['mysql']['port']
              version node['mysql']['version']  #'5.5'
              bind_address node['mysql']['bind_address']
              initial_root_password lazy { node.run_state['mysql_root_pass'] }
              socket lazy { node.run_state['mysql_socket'] }
              action :restart
              only_if { ::File.exists?( path_downloadfile ) && !::File.exists?( database_file_check )}
              notifies :write,"log[...... mysql restarted]", :immediately
            end

            # zcat moodle_unasus2-20150320.sql.gz | mysql -u root --database moodle_unasus2
            execute "descompacta a base de dados: [#{resource.dbname}]" do
              #cwd "#{resource.installdir}"
              command "zcat #{path_downloadfile} | #{mysql_path} -u root -h #{resource.dbhost} -P 3306 #{ node.run_state['mysql_root_pass_param'] } --database #{resource.dbname}"
              retries 6 # 6 times
              retry_delay 2 # 2 second
              only_if { ::File.exists?( path_downloadfile ) && !::File.exists?( database_file_check )}
              notifies :create, "file[#{database_file_check}]", :immediately
            end
          end
        end # database

        nginx_site resource.server_name + '.conf' if tcc_server_name.present?

      end

      def remove_tcc(resource)
        # server_name = resource.server_name.sub(/^https?\:\/\//, '')

        nginx_site resource.server_name + '.conf' do
          enable false
          only_if tcc_server_name.present?
        end

        database_file_check = "/etc/chef/databse_#{resource.dbname}_restored"
        file database_file_check do
          action :nothing
        end

        mysql_database "drop database: #{resource.dbname}" do
          database_name resource.dbname
          connection( db_connection )
          action :drop
          only_if "/usr/bin/mysql -u root -h 127.0.0.1 -P 3306 #{node.run_state['mysql_root_pass_param']} -e 'show databases'"
          notifies :delete, "file[#{database_file_check}]", :immediately
        end

        git_destination = resource.config_dir
        directory git_destination do
          recursive true
          action :delete
        end

      end

    end
  end
end