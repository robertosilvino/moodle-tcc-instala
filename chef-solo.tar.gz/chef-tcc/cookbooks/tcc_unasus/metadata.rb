name             'tcc_unasus'
maintainer       'Universidade Federal de Santa Catarina'
maintainer_email 'roberto.silvino@ufsc.br'
license          'All rights reserved'
description      'Installs/Configures tcc_unasus'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.0'

depends          'database'
depends          'nginx'
depends          'mysql2_chef_gem'
