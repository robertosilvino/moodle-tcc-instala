#
# Cookbook Name:: unasus_tcc
# Recipe:: tcc
#
# Copyright 2015, UnASUS/UFSC/SeTIC
#
# All rights reserved - Do Not Redistribute
#

include_recipe 'tcc_unasus'

Array(node['unasus']['tccs']).each do | tcc |

  # sets password for tcc user
  begin
    databag_dbuser = data_bag_item('db_users', tcc['dbuser'])
    dbpass = databag_dbuser['password']
  rescue
    Chef::Log.info("------ data_bag_item('db_users', #{tcc['dbuser']}) = #{tcc['dbpass']}")
    dbpass = tcc['dbpass'].to_s
  end

  # sets password for smtp user
  begin
    databag_dbuser = data_bag_item('other', "smtp_#{tcc['smtp_user_name']}")
    dbpass_smtp = databag_dbuser['password']
  rescue
    Chef::Log.info("------ data_bag_item('other', 'smtp_#{tcc['dbuser']}') = #{tcc['smtp_password']}")
    dbpass_smtp = tcc['smtp_password'].to_s
  end

  # sets password for moodle user
  begin
    moodle_dbuser = data_bag_item('db_users', tcc['moodle_dbuser'])
    dbpass_moodle = moodle_dbuser['password']
  rescue
    Chef::Log.info("------ data_bag_item('db_users', #{tcc['moodle_dbuser']}) = #{tcc['moodle_dbuser']}")
    dbpass_moodle = tcc['moodle_dbpass'].to_s
  end

  # sets newrelic_license_key
  begin
    keys_newrelic = data_bag_item('keys', 'newrelic_license_key')
    newrelic_license_key = keys_newrelic['key']
  rescue
    Chef::Log.info("------ data_bag_item('keys', 'newrelic_license_key') = #{tcc['newrelic_license_key']}")
    newrelic_license_key = tcc['newrelic_license_key'].to_s
  end

  # sets errbit_api_key for tcc['name']
  begin
    errbit_api = data_bag_item(tcc['name'], 'errbit_api_key')
    errbit_api_key = errbit_api['key'].to_s
  rescue
    Chef::Log.info("------ data_bag_item(#{tcc['name']}, 'errbit_api_key') = #{tcc['errbit_api_key']}")
    errbit_api_key = tcc['errbit_api_key']
  end

  # sets tcc_consumer_key for tcc['name']
  begin
    consumer_key = data_bag_item(tcc['name'], 'tcc_consumer_key')
    tcc_consumer_key = consumer_key['key'].to_s
  rescue
    Chef::Log.info("------ data_bag_item(#{tcc['name']}, 'tcc_consumer_key') = #{tcc['tcc_consumer_key']}")
    tcc_consumer_key = tcc['tcc_consumer_key']
  end

  # sets tcc_consumer_secret for tcc['name']
  begin
    consumer_secret = data_bag_item(tcc['name'], 'tcc_consumer_secret')
    tcc_consumer_secret = consumer_secret['secret']
  rescue
    Chef::Log.info("------ data_bag_item(#{tcc['name']}, 'tcc_consumer_secret') = #{tcc['tcc_consumer_secret']}")
    tcc_consumer_secret = tcc['tcc_consumer_secret'].to_s
  end

  # sets tcc_moodle_token for tcc['name']
  begin
    moodle_token = data_bag_item(tcc['name'], 'tcc_moodle_token')
    tcc_moodle_token = moodle_token['token']
  rescue
    Chef::Log.info("------ data_bag_item(#{tcc['name']}, 'tcc_moodle_token') = #{tcc['tcc_moodle_token']}")
    tcc_moodle_token = tcc['tcc_moodle_token'].to_s
  end

  tcc_install tcc['name'] do

    #name tcc['name']
    user_deploy tcc['user_deploy']
    config_dir tcc['config_dir']
    web_root_dir tcc['web_root_dir']
    create_db_and_user tcc['create_db_and_user']
    database_download_site tcc['database_download_site'] # 'http://192.168.25.29/central_atendimento-20150320.sql.gz'

    mysql_socket lazy { node.run_state['mysql_socket'] }

    dbgrant_hosts tcc['dbgrant_hosts']
    dbadapter     tcc['dbadapter']  # 'mysql2'
    dbhost        tcc['dbhost']     # 'localhost'
    dbname        tcc['dbname']     # 'redmine'
    dbuser        tcc['dbuser']
    dbpass        dbpass
    dbrootpass    lazy { node.run_state['mysql_root_pass'] }
    dbsocket      tcc['dbsocket'].nil? ? false : tcc['dbsocket']

    server_name     tcc['server_name']      # 'tcc.vm3local'
    web_root_dir    tcc['web_root_dir']     # '/home/deploy/tcc/current'
    git_auto_update tcc['git_auto_update']  # false
    git_repo        tcc['git_repo']         # 'git@gitlab.setic.ufsc.br:central-unasus/redmine.git'
    git_revision    tcc['git_revision']     # 'master'

    root_https tcc['root_https']            # false

    delivery_method     tcc['delivery_method']      # 'smtp'
    smtp_address        tcc['smtp_address']         # 'smtp.sistemas.ufsc.br'
    smtp_port           tcc['smtp_port']            # '25'
    smtp_authentication tcc['smtp_authentication']  # 'login'
    smtp_user_name      tcc['smtp_user_name']       # 'unasus'
    smtp_password       dbpass_smtp

    errbit_api_key errbit_api_key
    errbit_host    tcc['errbit_host'] # 'errbit.setic.ufsc.br'
    errbit_port    tcc['errbit_port'] # '443'

    moodle_dbadapter tcc['moodle_dbadapter'] # 'mysql2'
    moodle_dbhost   tcc['moodle_dbhost'] # 'localhost'
    moodle_dbname   tcc['moodle_dbname'] # 'moodle_unasus2'
    moodle_dbuser   tcc['moodle_dbuser'] # 'moodle'
    moodle_dbpass   dbpass_moodle
    moodle_dbport   tcc['moodle_dbport'] # '3306'
    moodle_dbsocket tcc['moodle_dbsocket'].nil? ? false : tcc['moodle_dbsocket']

    newrelic_license_key newrelic_license_key
    newrelic_app_name tcc['newrelic_app_name'] # 'TCC - vmlocal'

    tcc_moodle_url tcc['tcc_moodle_url'] # 'http://unasus2.vmlocal'
    tcc_moodle_token tcc_moodle_token
    tcc_consumer_key tcc_consumer_key
    tcc_consumer_secret tcc_consumer_secret
    tcc_notification_email  tcc['tcc_notification_email'] # 'unasus@sistemas.ufsc.br'

  end
end

