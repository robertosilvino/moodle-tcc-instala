default['tcc_unasus']['cookbook_template'] = 'tcc_unasus'
