#
# Cookbook Name:: teste_unasus
# Recipe:: default
#
# Copyright 2015, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#

include_recipe 'teste_unasus::tcca'