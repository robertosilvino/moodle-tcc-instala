Array(node['teste']['tccs']).each do | tcc |

  mysql_tcc_install tcc['name'] do
    dbadapter tcc['dbadapter']
    action :install
  end

  package 'htop' do
    action :install
  end
end