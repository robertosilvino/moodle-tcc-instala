Array(node['teste']['tccs']).each do | tcc |

  tccb tcc['name'] do
    config_dir tcc['config_dir']
    action :install
  end
end
