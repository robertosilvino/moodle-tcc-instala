require 'chef/resource/lwrp_base'

class Chef
  class Resource
    class MysqlTccInstall < Chef::Resource::LWRPBase
      self.resource_name = :mysql_tcc_install
      actions :install, :remove
      default_action :install

      provides :mysql_tcc_install

      # attribute :name,        kind_of: [ String ], name_attribute: true
      # attribute :user_deploy, kind_of: [ String ], default: 'deploy'
      attribute :dbadapter,     kind_of: [ String ], default: 'mysql2'
      attribute :dbhost,        kind_of: [ String ], default: 'localhost'
      attribute :dbname,        kind_of: [ String ], default: 'tcc_unasus'
      attribute :dbpass,        kind_of: [ String ], default: 'tcc_unasus'
      attribute :dbrootpass,    kind_of: [ String ], default: 'moodle'
      attribute :dbsocket,      kind_of: [ TrueClass, FalseClass ], default: false
      attribute :dbuser,        kind_of: [ String ], default: 'tcc'
      attribute :server_name,   kind_of: [ String ], default: '' #'localhost'
      attribute :web_root_dir,  kind_of: [ String ], default: ''

      # def initialize(*args)
      #   super
      #   @action = :create
      #
      # end
    end
  end
end