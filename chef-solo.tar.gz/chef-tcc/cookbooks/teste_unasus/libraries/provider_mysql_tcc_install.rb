class Chef
  class Provider
    class MysqlTccInstall < Chef::Provider::LWRPBase
      use_inline_resources

      def whyrun_supported?
        true
      end

      include Chef::DSL::IncludeRecipe
      include Chef::Mixin::ShellOut

      provides :mysql_tcc_install, os: 'linux' if respond_to?(:provides)

      action :install do

        log ">>>>>> Install new_resource" do
          message ">>>>>> Install new_resource #{new_resource.nil? ? 'vazio' : new_resource.dbadapter }"
          # message ">>>>>> Creating 456 #{current_resource.nil? ? 'vazio' : 'cheio'}"
          level :info
        end

        log "||| attribute?" do
          # "teste"."tccs"."config_dir"
          message "||| attribute? #{ node.attribute?('latex') ? 'sim' : 'não' }"
          level :info
        end

        log "||| attribute?" do
          # "teste"."tccs"."config_dir"
          message "||| attribute? #{ node['latex'].attribute?('version') ? 'sim' : 'não' }"
          level :info
        end
        # Software installation
        package 'phantomjs' do
          action :install
        end

      end

      action :remove do
      end
    end
  end
end