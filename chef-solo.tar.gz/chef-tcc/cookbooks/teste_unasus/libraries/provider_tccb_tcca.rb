class Chef
  class Provider
    class Tccb
      class Package < Chef::Provider::Tccb
        include Chef::DSL::IncludeRecipe

        provides :tccb, os: 'linux' if respond_to?(:provides)

        action :install do

          # Software installation
          log ">>>>>> Install config_dir" do
            message ">>>>>> Install config_dir #{new_resource.nil? ? 'vazio' : new_resource.config_dir }"
            level :info
          end

          package 'wget' do
            action :install
          end

        end

        action :remove do
        end
      end
    end
  end
end