require 'chef/resource/lwrp_base'

class Chef
  class Resource
    class Tccb < Chef::Resource::LWRPBase
      self.resource_name = :tccb
      actions :install, :remove
      default_action :install

      provides :tccb

      attribute :name,        kind_of: [ String ], name_attribute: true
      attribute :user_deploy, kind_of: [ String ], default: 'deploy'
      attribute :config_dir,  kind_of: [ String ], default: 'localhost'
      attribute :description, kind_of: [ String ],  default: 'UnASUS-TCC App'
    end
  end
end
