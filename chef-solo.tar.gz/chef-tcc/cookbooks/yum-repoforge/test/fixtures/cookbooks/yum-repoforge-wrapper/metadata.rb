name 'yum-repoforge-wrapper'
version '0.0.1'

depends 'yum-repoforge'
