# CHANGELOG for htop

This file is used to list changes made in each version of htop.

## 2.0.0:

* Migrate to the yum-repoforge cookbook.  The yum v3.0.0 cookbook removed the repoforge recipe.

## 1.1.0:

* add RedHat/CentOS support

## 1.0.0:

* Initial release of htop
