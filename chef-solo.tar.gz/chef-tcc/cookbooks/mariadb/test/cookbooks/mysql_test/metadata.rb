name 'mysql_test'
version '0.1.0'

depends 'database'
depends 'yum', '< 3.0'
