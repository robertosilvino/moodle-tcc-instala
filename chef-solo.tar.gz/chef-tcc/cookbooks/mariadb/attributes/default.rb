
default['mariadb']['version'] = '5.5'
default['mariadb']['disable_repo'] = false
